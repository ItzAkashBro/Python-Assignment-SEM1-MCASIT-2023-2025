#Write a Python program to map two lists into a dictionary.

l1 = {1,2,3,4}
l2 = {5,6,7,8}
dict = l1 | l2
print (dict)