# Program for Adding, removing elements in the list.

l = [1, 2, 3, 4, 5]
l.append(6)
print("List After adding elements:", l)
l.remove(3)
print("List After removing elements:", l)