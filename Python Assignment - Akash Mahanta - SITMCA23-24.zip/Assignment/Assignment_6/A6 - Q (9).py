# Program to Print the index of first matched element of a list.

l = [1, 2, 3, 4, 3, 5, 6]
e = 3
i = next((i for i, item in enumerate(l) if item == e), None)
print(f"Index of the first occurrence of {e}: {i}" if i is not None else f"{e} not found in the list.")