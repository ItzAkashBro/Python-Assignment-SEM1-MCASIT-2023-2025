# Program to remove first occurrence of a given element in the list.

l = [1, 2, 3, 4, 5, 3, 6]
e = 3
if e in l:
    l.remove(e)
    print(f"First occurrence of {e} removed. Final List: {l}")
else:
    print(f"{e} not found in the list.")