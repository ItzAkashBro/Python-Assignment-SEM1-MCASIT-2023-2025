# Program to print a list using 'FOR and IN' loop.

l = [1, 2, 3, 4, 5]
print("List elements using 'for' loop:")
for e in l:
    print(e)