# Program to remove all elements in a range from the List.

l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
s, e = 3, 7
l = [i for i in l if not (s <= i <= e)]
print(f"List after removing elements in the range {s}-{e}:", l)