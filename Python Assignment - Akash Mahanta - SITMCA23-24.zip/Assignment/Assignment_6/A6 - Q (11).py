# Input comma separated elements, convert into list and print.

e = input("Enter comma-separated elements: ").split(',')
print("List of elements:", e)