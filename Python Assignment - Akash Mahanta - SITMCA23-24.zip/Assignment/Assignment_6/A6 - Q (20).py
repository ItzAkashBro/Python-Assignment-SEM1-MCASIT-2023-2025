# print list after removing EVEN numbers.

l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
r = [num for num in l if num % 2 != 0]
print("List after Removing Even Numbers:", r)