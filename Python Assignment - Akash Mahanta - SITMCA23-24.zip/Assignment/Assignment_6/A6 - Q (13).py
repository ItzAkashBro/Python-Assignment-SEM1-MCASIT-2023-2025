# Program to input, append and print the list elements.

l = []
l.extend(input("Enter elements separated by space: ").split())
print("List after appending elements:", l)