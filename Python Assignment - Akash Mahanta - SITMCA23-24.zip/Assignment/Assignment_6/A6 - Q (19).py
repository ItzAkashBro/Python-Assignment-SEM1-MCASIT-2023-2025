# Create a list from the specified start to end index of another list

l = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
s, e = 2, 7
new_list = l[s:e + 1]
print("New List from index {} to {}: {}".format(s, e, new_list))