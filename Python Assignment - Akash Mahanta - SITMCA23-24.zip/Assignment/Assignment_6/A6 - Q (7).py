# Remove all occurrences a given element from the list.

l = [1, 2, 3, 4, 3, 5, 3, 6]
e = 3
l = [item for item in l if item != e]
print("List after removing all occurrences of", e, ":", l)