# Convert a string to integers list.

s = "1 2 3 4 5"
i = list(map(int, s.split()))
print("List of integers:", i)