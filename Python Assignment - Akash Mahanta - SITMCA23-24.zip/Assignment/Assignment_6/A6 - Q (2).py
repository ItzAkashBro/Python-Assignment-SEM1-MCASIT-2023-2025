# Python program to print list elements in different ways.

l = [1, 2, 3, 4, 5]
print("List:", l)
print("List in loop:", *l)
print("List in reverse loop:", *reversed(l))
print("List in list comprehension:", *[element for element in l])
print("List in join and map:", ' '.join(map(str, l)))