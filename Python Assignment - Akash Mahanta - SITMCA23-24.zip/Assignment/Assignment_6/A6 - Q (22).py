# Create three lists of numbers, their squares and cubes.

n = [1, 2, 3, 4, 5]
s = [num ** 2 for num in n]
c = [num ** 3 for num in n]
print("Numbers:", n)
print("Squares:", s)
print("Cubes:", c)