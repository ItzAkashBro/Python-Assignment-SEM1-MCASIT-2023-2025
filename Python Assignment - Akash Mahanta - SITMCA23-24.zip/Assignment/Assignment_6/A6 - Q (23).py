# Create two lists with first half and second half elements of a list.

ol = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
m = len(ol) // 2
f, s = ol[:m], ol[m:]
print("First Half:", f)
print("Second Half:", s)