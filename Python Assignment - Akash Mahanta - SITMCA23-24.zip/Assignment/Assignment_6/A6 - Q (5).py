# Program to add an element at specified index in a list.

l = [1, 2, 3, 4, 5]
element_to_add, index_to_add = 10, 2
l.insert(index_to_add, element_to_add)
print("Final List:", l)