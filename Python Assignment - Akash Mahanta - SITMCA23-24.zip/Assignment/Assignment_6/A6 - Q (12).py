# Program to find the position of minimum and maximum elements of a list.

l = [5, 2, 8, 1, 7, 3, 9, 4, 6]
min = l.index(min(l))
max = l.index(max(l))
print("List:", l)
print("Position of the minimum element:", min)
print("Position of the maximum element:", max)