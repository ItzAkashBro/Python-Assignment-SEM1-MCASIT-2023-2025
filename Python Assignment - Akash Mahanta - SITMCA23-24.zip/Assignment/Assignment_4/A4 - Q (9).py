# Write a program in C to calculate Power(a,b) using function.

def power(a,b):
    return a**b
a=int(input('Enter a value:'))
b=int(input('Enter b value:'))
print('Power(a,b) is:',power(a,b))