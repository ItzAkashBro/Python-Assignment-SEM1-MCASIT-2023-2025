# Write a program in C to find the square of any number using the function.

def square(num):
    return num**2
num=int(input('Enter A number:'))
print(f"Square of {num} is: {square(num)}")