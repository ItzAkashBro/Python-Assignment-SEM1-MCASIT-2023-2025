# Find the absolute value of a number entered through the keyboard.

Number = float(input("Enter a value: "))
print(f"The Absolute value of {Number} is: {abs(Number)}")
