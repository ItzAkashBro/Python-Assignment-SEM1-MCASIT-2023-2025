# Temperature of a city in Fahrenheit degrees is input through the keyboard.
# Write a program to convert this temperature into Centigrade degrees.

Ftemp=int(input("Enter Temp In ferenhite\n"))
print("temp in centigrade is :-",(Ftemp-32)*(5/9))