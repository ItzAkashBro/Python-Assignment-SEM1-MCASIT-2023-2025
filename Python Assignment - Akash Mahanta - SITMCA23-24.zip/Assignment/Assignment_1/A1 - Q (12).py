# If the total selling price of 15 items and the total profit earned on them is input through the keyboard,
# write a program to find the cost price of one item.

s=int(input("Enter total selling price: "))
p=int(input("Enter total Profit amount: "))
print("Cost per Item is:",(s-p)/15)