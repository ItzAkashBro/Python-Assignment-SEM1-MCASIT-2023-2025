# The distance between two cities (in km.) is input through the keyboard.
# Write a program to convert and print this distance in meters, feet, inches and centimeters.

Distance=int(input("Enter the distance Between Two cities(KM):-\n"))
print("distance in meter is:-",Distance*1000)
print("distance in Feet is:-",Distance*3280.84)
print("distance in Inch is:-",Distance*39370.1)
print("distance in Cm is:-",Distance*100000)



