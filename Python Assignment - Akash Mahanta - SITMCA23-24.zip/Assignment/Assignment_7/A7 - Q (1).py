# Create a function to print your name using Python.

def print_name():
    name = "Akash"
    print("My name is:", name)
print_name()