# Write a Python program to understand the use
# of asterisk(*) character declared in a function.

def ast(*args):
    for are in args:
        print(args)
ast(1,2,3,4,5)