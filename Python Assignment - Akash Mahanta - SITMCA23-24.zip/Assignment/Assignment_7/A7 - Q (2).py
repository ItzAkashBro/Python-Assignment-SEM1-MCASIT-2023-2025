# Write a program to add two integers using function.

def add_numbers(a, b):
    return a + b
num1 = 2
num2 = 8
print(f"The sum is: {add_numbers(num1, num2)}")