# Write a Python function to sum all the numbers in a list.

def s(numbers):
    return sum(numbers)
r = s([10, 25, 15, 30, 20])
print(f"The sum is: {r}")