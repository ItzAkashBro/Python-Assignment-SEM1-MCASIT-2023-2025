# Create a function to multiply two numbers and
# the numbers should pass as parameter and return the result.

def mul(a, b):
    return a * b
n1 = 5
n2 = 3
print(f"The product is: {mul(n1, n2)}")