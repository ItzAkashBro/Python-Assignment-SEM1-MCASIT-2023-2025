# Write a program to find the range of a set of numbers.
# Range is the difference between the smallest and biggest number in the list.

L=[1,2,4,5,3]
smallest=min(L)
biggest=max(L)
print(f"difference between numbers is {biggest-smallest}")
    