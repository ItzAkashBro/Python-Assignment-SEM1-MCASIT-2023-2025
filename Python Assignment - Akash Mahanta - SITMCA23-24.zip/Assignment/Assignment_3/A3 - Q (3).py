# Two numbers  are entered through the keyboard.
# Write a program to find the value of one number raised to the power of another.

number=int(input("Enter The number:- "))
power=int(input("enter the power:- "))
answer=number**power
print("value is ",answer)